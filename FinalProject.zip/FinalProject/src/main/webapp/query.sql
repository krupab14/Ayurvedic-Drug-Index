INSERT INTO dosagedata (SrNo, Dose, PrecautionContraindications, Class) VALUES
(1, '1 tsp', 'None', 'Rasayana'),
(2, '1 Tablet', 'Pregnancy', 'Adaptogen'),
(3, '1 tsp', 'None', 'Digestive'),
(4, '1 Tablet', 'None', 'Cognitive'),
(5, '10ml', 'None', 'Respiratory'),
(6, '1 Tablet', 'Pregnancy', 'Skin'),
(7, '10ml', 'None', 'Vitamin'),
(8, '1 Tablet', 'None', 'Women’s Health'),
(9, '1 Tablet', 'None', 'Cardiac'),
(10, '1 Tablet', 'None', 'Nutritional'),
(11, '1 tsp', 'None', 'Digestive'),
(12, '1 Tablet', 'Pregnancy', 'Urinary'),
(13, '1 Tablet', 'Pregnancy', 'Hepatic'),
(14, '1 Tablet', 'None', 'Immunity'),
(15, '1g', 'Pregnancy', 'Energy'),
(16, '1 Tablet', 'Pregnancy', 'Hepatic'),
(17, '1 Tablet', 'None', 'Blood Purifier'),
(18, '1 Tablet', 'None', 'Digestive'),
(19, '1 Tablet', 'None', 'Urinary'),
(20, '1 tsp', 'None', 'Digestive');



INSERT INTO pharmalogicaldata (SrNo, NameOfMedicine, ReferenceText, DispensingPackSize, MainIndications, PreferredUse, Class) VALUES
(1, 'Chyawanprash', 'Ayurvedic Texts', '500g', 'Immunity Booster', 'Daily Use', 'Rasayana'),
(2, 'Ashwagandha', 'Ayurvedic Texts', '60 Tablets', 'Stress Relief', 'Twice Daily', 'Adaptogen'),
(3, 'Triphala', 'Ayurvedic Texts', '100g', 'Digestive Health', 'Before Meals', 'Digestive'),
(4, 'Brahmi', 'Ayurvedic Texts', '60 Tablets', 'Memory Enhancer', 'Twice Daily', 'Cognitive'),
(5, 'Tulsi', 'Ayurvedic Texts', '100ml', 'Respiratory Health', 'Daily Use', 'Respiratory'),
(6, 'Neem', 'Ayurvedic Texts', '60 Tablets', 'Skin Health', 'Daily Use', 'Skin'),
(7, 'Amla', 'Ayurvedic Texts', '500ml', 'Vitamin C Source', 'Daily Use', 'Vitamin'),
(8, 'Shatavari', 'Ayurvedic Texts', '60 Tablets', 'Female Health', 'Twice Daily', 'Women’s Health'),
(9, 'Arjuna', 'Ayurvedic Texts', '60 Tablets', 'Heart Health', 'Twice Daily', 'Cardiac'),
(10, 'Moringa', 'Ayurvedic Texts', '60 Tablets', 'Nutritional Supplement', 'Daily Use', 'Nutritional'),
(11, 'Trikatu', 'Ayurvedic Texts', '100g', 'Metabolism Booster', 'Before Meals', 'Digestive'),
(12, 'Gokshura', 'Ayurvedic Texts', '60 Tablets', 'Urinary Health', 'Twice Daily', 'Urinary'),
(13, 'Kutki', 'Ayurvedic Texts', '60 Tablets', 'Liver Health', 'Twice Daily', 'Hepatic'),
(14, 'Guduchi', 'Ayurvedic Texts', '60 Tablets', 'Immune Support', 'Daily Use', 'Immunity'),
(15, 'Shilajit', 'Ayurvedic Texts', '20g', 'Energy Booster', 'Daily Use', 'Energy'),
(16, 'Bhumyamalaki', 'Ayurvedic Texts', '60 Tablets', 'Liver Support', 'Twice Daily', 'Hepatic'),
(17, 'Manjistha', 'Ayurvedic Texts', '60 Tablets', 'Blood Purifier', 'Twice Daily', 'Blood Purifier'),
(18, 'Yashtimadhu', 'Ayurvedic Texts', '60 Tablets', 'Digestive Health', 'Twice Daily', 'Digestive'),
(19, 'Punarnava', 'Ayurvedic Texts', '60 Tablets', 'Kidney Health', 'Twice Daily', 'Urinary'),
(20, 'Haritaki', 'Ayurvedic Texts', '100g', 'Digestive Health', 'Before Meals', 'Digestive');


CREATE TABLE dosagedata (
    SrNo INT(11),
    Dose VARCHAR(255) COLLATE utf8mb4_general_ci,
    PrecautionContraindications TEXT COLLATE utf8mb4_general_ci,
    Class VARCHAR(100) COLLATE utf8mb4_general_ci
);


CREATE TABLE pharmalogicaldata (
    SrNo INT(11) NOT NULL AUTO_INCREMENT,
    NameOfMedicine VARCHAR(255) COLLATE utf8mb4_general_ci,
    ReferenceText VARCHAR(255) COLLATE utf8mb4_general_ci,
    DispensingPackSize VARCHAR(255) COLLATE utf8mb4_general_ci,
    MainIndications TEXT COLLATE utf8mb4_general_ci,
    PreferredUse VARCHAR(50) COLLATE utf8mb4_general_ci,
    Class VARCHAR(100) COLLATE utf8mb4_general_ci,
    PRIMARY KEY (SrNo)
);


-- Disable foreign key checks
SET FOREIGN_KEY_CHECKS = 0;

-- Truncate the tables
TRUNCATE TABLE dosagedata;
TRUNCATE TABLE pharmalogicaldata;

-- Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;
